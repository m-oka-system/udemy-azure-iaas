configuration IISInstall
{
    node "localhost"
    {
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
        }
        
        File Index-html
        {
            Ensure = "Present"
            Type = "File"
            Contents = "<h1>$($env:computername)</h1>"
            DestinationPath = "C:\inetpub\wwwroot\index.html"
        }
    }
}